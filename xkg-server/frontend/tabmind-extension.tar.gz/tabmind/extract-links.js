const puppeteer = require('puppeteer');

const url = process.argv[2] || 'https://x.com';

async function extractLinks() {
  console.log(`Launching browser for: ${url}`);
  
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  const page = await browser.newPage();
  
  try {
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
    
    // Wait for content to load
    await page.waitForTimeout(3000);
    
    // Get page content
    const title = await page.title();
    console.log('Page title:', title);
    
    // Extract all links
    const links = await page.evaluate(() => {
      const anchors = document.querySelectorAll('a[href]');
      const urls = [];
      anchors.forEach(a => {
        const href = a.href;
        if (href && href.startsWith('http')) {
          urls.push(href);
        }
      });
      return [...new Set(urls)];
    });
    
    console.log('\n=== All Links Found ===');
    links.forEach(link => console.log(link));
    
    // Filter GitHub links
    const githubLinks = links.filter(l => l.includes('github.com'));
    console.log('\n=== GitHub Links ===');
    githubLinks.forEach(link => console.log(link));
    
    // Extract page text
    const text = await page.evaluate(() => document.body.innerText.substring(0, 5000));
    console.log('\n=== Page Content (first 5000 chars) ===');
    console.log(text);
    
  } catch (e) {
    console.error('Error:', e.message);
  } finally {
    await browser.close();
  }
}

extractLinks();