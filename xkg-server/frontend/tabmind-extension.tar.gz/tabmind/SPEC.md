# XKG Tab Search - Specification

## Project Overview

- **Name:** XKG Tab Search
- **Type:** Chrome/Brave Extension
- **Purpose:** Search content of all open tabs, auto-export Grok conversations to XKG
- **Target:** XKG users with many browser tabs

## Core Features

### 1. Tab Content Search
- Index all open tabs on popup open
- Full-text search across page content
- Relevance ranking
- Keyboard navigation (arrow keys + Enter)
- Click result → jump to tab + highlight match

### 2. Grok Conversation Capture
- Detect x.com/grok tabs
- Auto-export new conversations to XKG
- Push via XKG API endpoint

### 3. XKG Integration
- Configure XKG API endpoint
- Background sync
- Manual export button

## Technical Architecture

```
manifest.json          # Extension manifest (MV3)
├── popup/
│   ├── popup.html     # Search UI
│   ├── popup.js      # Search logic
│   └── styles.css    # Styling
├── background/
│   ├── background.js # Service worker
│   └── grok.js       # Grok detection
├── content/
│   └── content.js   # Page content extraction
└── lib/
    └── flexsearch   # Local search index
```

## API Endpoints (XKG side)

```
POST /api/tab-import    # Import tab content
GET  /api/tabs/status   # Sync status
```

## MVP Scope

- [x] Basic tab search
- [x] Content indexing
- [ ] Grok tab detection
- [ ] Auto-export to XKG
- [ ] Settings page

## Install (Brave)

1. `npm install`
2. `npm run build`
3. brave://extensions → Developer Mode → Load unpacked → dist/
