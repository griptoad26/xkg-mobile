const http = require('http');

async function cdpRequest(method, params = {}) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify({ id: 1, method, params });
    const req = http.request({
      hostname: 'localhost',
      port: 9222,
      path: '/json',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, res => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(body)); } catch(e) { resolve(body); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

async function main() {
  console.log('=== TabMind Extension Test ===\n');
  
  // Get tabs
  const response = await new Promise((resolve, reject) => {
    http.get('http://localhost:9222/json', res => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => resolve(JSON.parse(body)));
    }).on('error', reject);
  });
  
  console.log('Open tabs/pages:', response.length);
  
  // Look for our extension
  const ext = response.find(r => r.url.includes('tabmind') || r.title?.includes('TabMind'));
  if (ext) {
    console.log('Found extension:', ext.title, ext.url);
  } else {
    console.log('Extension not loaded yet');
  }
  
  // Check for tabs with content
  console.log('\nAll targets:');
  response.forEach((r, i) => {
    console.log(`  ${i+1}. ${r.type}: ${r.title?.substring(0,50)}`);
  });
}

main().catch(console.error);
