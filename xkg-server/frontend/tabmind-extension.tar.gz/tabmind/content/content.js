// XKG Tab Search - Content Script
// Runs on every page to extract content for indexing

(function() {
  // Only run on Grok pages
  const isGrokPage = window.location.href.includes('x.com/grok') || 
                     window.location.href.includes('grok.com');
  
  // Extract content after page settles
  function extractContent() {
    const excludeSelectors = [
      'script', 'style', 'noscript', 'iframe', 
      'nav', 'header', 'footer', 'aside',
      '.nav', '.menu', '.sidebar', '.ad', '.advertisement',
      '[role="navigation"]', '[role="banner"]', '[role="complementary"]'
    ];
    
    const clone = document.body.cloneNode(true);
    excludeSelectors.forEach(selector => {
      try {
        clone.querySelectorAll(selector).forEach(el => el.remove());
      } catch (e) {
        // Ignore selector errors
      }
    });
    
    let text = clone.body?.textContent || '';
    text = text.replace(/\s+/g, ' ').trim();
    
    return text.substring(0, 50000);
  }
  
  // Send content to background script
  function reportContent() {
    const content = extractContent();
    
    if (content && content.length > 100) {
      chrome.runtime.sendMessage({
        action: 'contentExtracted',
        tabId: chrome.runtime.id,
        url: window.location.href,
        title: document.title,
        content: content,
        isGrok: isGrokPage
      }).catch(() => {
        // Ignore errors (popup may not be open)
      });
    }
  }
  
  // Extract on load
  if (document.readyState === 'complete') {
    reportContent();
  } else {
    window.addEventListener('load', reportContent);
  }
  
  // Re-extract on significant DOM changes (for SPA navigation)
  let lastUrl = window.location.href;
  const observer = new MutationObserver(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      setTimeout(reportContent, 1000); // Wait for content to render
    }
  });
  
  observer.observe(document.body, { 
    childList: true, 
    subtree: true 
  });
})();
