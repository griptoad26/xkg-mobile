// XKG Tab Search - Popup Script

let tabsIndex = [];
let selectedIndex = -1;
let settings = {
  xkgEndpoint: 'http://localhost:18050',
  autoSyncGrok: false
};
let lastSearch = '';

function loadSavedSearch() {
  chrome.storage.local.get(['tabmindLastSearch'], (result) => {
    if (result.tabmindLastSearch) {
      lastSearch = result.tabmindLastSearch;
      document.getElementById('searchInput').value = lastSearch;
      if (lastSearch.trim()) {
        search(lastSearch);
      }
    }
  });
}

function saveSearch(query) {
  lastSearch = query;
  chrome.storage.local.set({ tabmindLastSearch: query });
}

document.addEventListener('DOMContentLoaded', async () => {
  loadSettings();
  await indexTabs();
  loadSavedSearch();
  setupEventListeners();
  updateStatus('ready');
});

function loadSettings() {
  chrome.storage.local.get(['xkgSettings'], (result) => {
    if (result.xkgSettings) {
      settings = { ...settings, ...result.xkgSettings };
      document.getElementById('xkgEndpoint').value = settings.xkgEndpoint;
      document.getElementById('autoSyncGrok').checked = settings.autoSyncGrok;
    }
  });
}

function saveSettings() {
  settings.xkgEndpoint = document.getElementById('xkgEndpoint').value;
  settings.autoSyncGrok = document.getElementById('autoSyncGrok').checked;
  chrome.storage.local.set({ xkgSettings: settings }, () => {
    toggleSettings(false);
  });
}

function toggleSettings(show) {
  document.getElementById('settingsPanel').classList.toggle('hidden', !show);
}

function isSuspendedTab(tab) {
  if (!tab.url) return false;
  const url = tab.url.toLowerCase();
  
  // The Great Suspender - original & forks
  // Pattern: chrome-extension://[ID]/suspended.html
  if (url.includes('suspended.html')) return true;
  if (url.includes('/suspended/')) return true;
  
  // The Great Suspender Reloaded / Marvellous Suspender / Tiny Suspender
  if (url.includes('tubsuspended')) return true;
  
  // Workona Tab Suspender
  if (url.includes('workona.com/tabs/suspended')) return true;
  if (url.includes('workona.com/tab-suspend')) return true;
  
  // Chrome's built-in tab suspender (newer Chrome versions)
  if (url.startsWith('chrome-untrusted://')) return true;
  
  // Firefox suspended tabs
  if (url.includes('about:suspended')) return true;
  
  // Generic: any chrome-extension with suspend in path
  if (url.includes('chrome-extension') && url.includes('suspend')) return true;
  
  // Chrome's " tab discarding" - low memory
  if (url.startsWith('chrome://discards/')) return true;
  
  return false;
}

async function wakeUpTab(tabId) {
  try {
    await chrome.tabs.reload(tabId);
    return true;
  } catch (e) {
    console.log('Wake failed:', e);
    return false;
  }
}

async function indexTabs() {
  updateStatus('indexing');
  console.log('Starting indexing...');
  
  try {
    const tabs = await chrome.tabs.query({});
    console.log('Found tabs:', tabs.length);
    
    tabsIndex = [];
    let successCount = 0;
    let grokCount = 0;
    
    // First pass: load from cache (instant)
    for (const tab of tabs) {
      if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('brave://')) {
        continue;
      }
      
      const tabIsGrok = tab.url.includes('x.com/grok') || tab.url.includes('grok.com') || tab.url.includes('x.com/i/grok');
      if (tabIsGrok) grokCount++;
      
      const isSuspended = isSuspendedTab(tab);
      
      tabsIndex.push({
        id: tab.id,
        title: tab.title,
        url: tab.url,
        favicon: tab.favIconUrl,
        content: '', // Will populate from cache or async
        isGrok: tabIsGrok,
        isSuspended: isSuspended
      });
    }
    
    // Show tabs immediately with titles/urls
    search(lastSearch);
    
    // Second pass: extract content from active/visible tabs only (fast)
    const activeTab = tabs.find(t => t.active);
    if (activeTab && !isSuspendedTab(activeTab)) {
      const content = await getTabContentFast(activeTab.id);
      if (content) {
        const idx = tabsIndex.findIndex(t => t.id === activeTab.id);
        if (idx !== -1) tabsIndex[idx].content = content;
        successCount++;
      }
    }
    
    // Third pass: background index other tabs (slow, non-blocking)
    setTimeout(() => indexTabsInBackground(tabs), 500);
    
    let statusText = `${tabsIndex.length} tabs`;
    if (successCount > 0) statusText += ` (${successCount}+ indexed)`;
    if (grokCount > 0) statusText += `, ${grokCount} Grok`;
    console.log('=== INDEXING COMPLETE ===', statusText);
    document.getElementById('tabsCount').textContent = statusText;
    updateStatus('ready');
    
  } catch (error) {
    console.error('Indexing error:', error);
    updateStatus('error');
  }
}

async function getTabContentFast(tabId) {
  try {
    // Check cache first
    const cached = await new Promise((resolve) => {
      chrome.storage.local.get([`tab-content-${tabId}`], (result) => {
        resolve(result[`tab-content-${tabId}`]?.content || null);
      });
    });
    
    if (cached && cached.length > 10) {
      console.log('Cache hit for tab', tabId);
      return cached;
    }
    
    console.log('Requesting content from background for tab', tabId);
    
    // Get from background
    const response = await chrome.runtime.sendMessage({
      action: 'getTabContent',
      tabId: tabId
    });
    
    console.log('Background response for tab', tabId, ':', response?.text?.length || 0, 'chars');
    
    return response?.text || null;
  } catch (e) {
    console.log('getTabContentFast error:', e.message);
    return null;
  }
}

async function indexTabsInBackground(tabs) {
  let successCount = 0;
  
  // Only index first 10 non-suspended tabs
  const toIndex = tabs.filter(t => !isSuspendedTab(t) && t.url?.startsWith('http')).slice(0, 10);
  
  for (const tab of toIndex) {
    const content = await getTabContentFast(tab.id);
    if (content) {
      const idx = tabsIndex.findIndex(t => t.id === tab.id);
      if (idx !== -1) tabsIndex[idx].content = content;
      successCount++;
    }
  }
  
  if (successCount > 0) {
    console.log('Background indexed:', successCount, 'more tabs');
    search(lastSearch); // Refresh results
  }
}

function extractGitHubLinks(content) {
  if (!content) return [];
  const githubPattern = /https?:\/\/github\.com\/[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+/gi;
  const matches = content.match(githubPattern) || [];
  return [...new Set(matches)]; // Remove duplicates
}

function search(query) {
  const results = document.getElementById('results');
  
  // Extract and display GitHub links from all tabs
  if (query.trim() === '') {
    // Show all tabs with their GitHub links
    results.innerHTML = tabsIndex.map((tab) => {
      const githubLinks = extractGitHubLinks(tab.content);
      const preview = tab.content ? tab.content.substring(0, 80).replace(/\s+/g, ' ') : '';
      return `
        <div class="result-item ${tab.isGrok ? 'grok' : ''}" data-tab-id="${tab.id}">
          <div class="result-title">
            ${escapeHtml(tab.title || 'Untitled')}
            ${tab.isGrok ? '<span class="result-badge">Grok</span>' : ''}
            ${tab.isSuspended ? '<span class="result-badge">💤</span>' : ''}
          </div>
          <div class="result-url">${escapeHtml(tab.url || '')}</div>
          ${githubLinks.length > 0 ? `
            <div class="github-links">
              ${githubLinks.map(link => `<a href="${link}" class="github-link" target="_blank">${link.replace('https://github.com/', '')}</a>`).join('')}
            </div>
          ` : ''}
          ${preview ? `<div class="result-context">${escapeHtml(preview)}...</div>` : ''}
        </div>
      `;
    }).join('');
    return;
  }
  
  const queryLower = query.toLowerCase();
  
  const scored = tabsIndex.map((tab) => {
    let score = 0;
    let context = '';
    let matchCount = 0;
    
    const titleLower = (tab.title || '').toLowerCase();
    const urlLower = (tab.url || '').toLowerCase();
    const contentLower = (tab.content || '').toLowerCase();
    
    if (titleLower.includes(queryLower)) score += 10;
    if (urlLower.includes(queryLower)) score += 5;
    if (contentLower.includes(queryLower)) {
      matchCount = (contentLower.match(new RegExp(escapeRegex(queryLower), 'g')) || []).length;
      score += Math.min(matchCount * 2, 20);
      
      const idx = contentLower.indexOf(queryLower);
      if (idx !== -1) {
        const start = Math.max(0, idx - 50);
        const end = Math.min(tab.content.length, idx + query.length + 50);
        context = tab.content.substring(start, end);
        if (start > 0) context = '...' + context;
        if (end < tab.content.length) context = context + '...';
      }
    }
    if (tab.isGrok) score += 3;
    if (tab.isSuspended) score -= 5; // Deprioritize suspended
    
    return { ...tab, score, context, matchCount };
  });
  
  const filtered = scored.filter(t => t.score > 0).sort((a, b) => b.score - a.score).slice(0, 20);
  
  if (filtered.length === 0) {
    results.innerHTML = `<div class="empty-state">No results for "${escapeHtml(query)}"</div>`;
    return;
  }
  
  results.innerHTML = filtered.map((tab) => {
    let contextHtml = '';
    if (tab.context) {
      const highlighted = tab.context.replace(
        new RegExp(`(${escapeRegex(query)})`, 'gi'),
        '<mark>$1</mark>'
      );
      contextHtml = `<div class="result-context">${highlighted}</div>`;
    }
    
    return `
      <div class="result-item ${tab.isGrok ? 'grok' : ''}" data-tab-id="${tab.id}">
        <div class="result-title">
          ${escapeHtml(tab.title || 'Untitled')}
          ${tab.isGrok ? '<span class="result-badge">Grok</span>' : ''}
          ${tab.matchCount > 1 ? `<span class="result-badge matches">${tab.matchCount} matches</span>` : ''}
        </div>
        <div class="result-url">${escapeHtml(tab.url || '')}</div>
        ${contextHtml}
      </div>
    `;
  }).join('');
  
  selectedIndex = 0;
  updateSelection();
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function escapeRegex(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function updateSelection() {
  document.querySelectorAll('.result-item').forEach((el, i) => {
    el.classList.toggle('selected', i === selectedIndex);
  });
}

function jumpToTab(tabId) {
  console.log('Jumping to tab:', tabId);
  chrome.tabs.update(tabId, { active: true }, (tab) => {
    if (tab && tab.windowId) {
      chrome.windows.update(tab.windowId, { focused: true });
    }
  });
  window.close();
}

async function wakeAllAndIndex() {
  const btn = document.getElementById('wakeAll');
  btn.textContent = 'Waking...';
  btn.disabled = true;
  
  const tabs = await chrome.tabs.query({});
  let wokenCount = 0;
  
  for (const tab of tabs) {
    if (isSuspendedTab(tab)) {
      try {
        await chrome.tabs.reload(tab.id);
        wokenCount++;
        await new Promise(r => setTimeout(r, 200)); // Small delay between tabs
      } catch (e) {
        console.log('Failed to wake tab:', tab.id, e);
      }
    }
  }
  
  btn.textContent = `Woke ${wokenCount}`;
  
  // Wait for tabs to load, then index
  setTimeout(async () => {
    await indexTabs();
    btn.textContent = '☀ Wake';
    btn.disabled = false;
  }, 2000);
}

function isGrokTab(url) {
  if (!url) return false;
  return url.includes('x.com/grok') || 
         url.includes('grok.com') ||
         url.includes('x.com/i/grok') ||
         url.includes('grok.com/');
}

async function syncGrok() {
  const allTabs = await chrome.tabs.query({});
  
  // Wake all suspended Grok tabs first
  const suspendedGrok = allTabs.filter(t => isGrokTab(t.url) && isSuspendedTab(t));
  
  for (const tab of suspendedGrok) {
    await wakeUpTab(tab.id);
    await new Promise(r => setTimeout(r, 300));
  }
  
  const grokTabs = allTabs.filter(t => isGrokTab(t.url));
  
  if (grokTabs.length === 0) {
    alert('No Grok tabs found. Make sure you have x.com/grok tabs open.');
    return;
  }
  
  const btn = document.getElementById('syncGrok');
  btn.textContent = 'Syncing...';
  btn.disabled = true;
  
  let synced = 0;
  
  try {
    for (const tab of grokTabs) {
      try {
        const content = await getTabContentFast(tab.id);
        
        if (content && content.length > 20) {
          await fetch(`${settings.xkgEndpoint}/api/tab-import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              title: tab.title || 'Grok Conversation',
              url: tab.url,
              content: content,
              timestamp: Date.now()
            })
          });
          synced++;
        }
      } catch (e) {
        console.log('Sync error:', e);
      }
    }
    
    btn.textContent = synced > 0 ? `✓ ${synced} synced!` : 'Failed';
    setTimeout(() => {
      btn.textContent = 'Sync Grok';
      btn.disabled = false;
    }, 3000);
    
  } catch (error) {
    btn.textContent = 'Error';
    btn.disabled = false;
    alert('Sync failed. Make sure XKG is running at ' + settings.xkgEndpoint);
  }
}

function updateStatus(status) {
  document.querySelectorAll('.status span').forEach(el => el.classList.add('hidden'));
  
  if (status === 'indexing') {
    document.querySelector('.status .indexing').classList.remove('hidden');
  } else if (status === 'ready') {
    document.querySelector('.status .ready').classList.remove('hidden');
  }
}

function setupEventListeners() {
  const searchInput = document.getElementById('searchInput');
  const results = document.getElementById('results');
  
  searchInput.addEventListener('input', (e) => {
    const query = e.target.value;
    saveSearch(query);
    search(query);
  });
  
  searchInput.addEventListener('keydown', (e) => {
    const items = document.querySelectorAll('.result-item');
    
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
      updateSelection();
      scrollToSelected();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      selectedIndex = Math.max(selectedIndex - 1, 0);
      updateSelection();
      scrollToSelected();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const selected = document.querySelector('.result-item.selected');
      if (selected) {
        jumpToTab(parseInt(selected.dataset.tabId));
      }
    } else if (e.key === 'Escape') {
      window.close();
    }
  });
  
  results.addEventListener('click', (e) => {
    const item = e.target.closest('.result-item');
    if (item) {
      jumpToTab(parseInt(item.dataset.tabId));
    }
  });
  
  document.getElementById('syncGrok').addEventListener('click', syncGrok);
  document.getElementById('wakeAll').addEventListener('click', wakeAllAndIndex);
  document.getElementById('settingsBtn').addEventListener('click', () => toggleSettings(true));
  document.getElementById('saveSettings').addEventListener('click', saveSettings);
  document.getElementById('closeSettings').addEventListener('click', () => toggleSettings(false));
}

function scrollToSelected() {
  const selected = document.querySelector('.result-item.selected');
  if (selected) {
    selected.scrollIntoView({ block: 'nearest' });
  }
}

// Group Panel Functions
function toggleGroupPanel(show) {
  document.getElementById('groupPanel').classList.toggle('hidden', !show);
}

async function groupByDomain() {
  document.getElementById('groupList').innerHTML = '<p class="hint">Grouping by domain...</p>';
  
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const domainGroups = {};
    
    for (const tab of tabs) {
      try {
        const url = new URL(tab.url);
        const domain = url.hostname;
        if (!domainGroups[domain]) domainGroups[domain] = [];
        domainGroups[domain].push(tab.id);
      } catch (e) {}
    }
    
    let groupCount = 0;
    for (const [domain, tabIds] of Object.entries(domainGroups)) {
      if (tabIds.length > 1) {
        const groupId = await chrome.tabs.group({ tabIds });
        await chrome.tabGroups.update(groupId, { title: domain.substring(0, 15), color: 'blue' });
        groupCount++;
      }
    }
    
    document.getElementById('groupList').innerHTML = `<p class="hint">✅ Created ${groupCount} groups</p>`;
  } catch (e) {
    document.getElementById('groupList').innerHTML = `<p class="hint">❌ Error: ${e.message}</p>`;
  }
}

async function groupGrokTabs() {
  document.getElementById('groupList').innerHTML = '<p class="hint">Grouping Grok tabs...</p>';
  
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const grokTabs = tabs.filter(t => t.url?.includes('grok'));
    
    if (grokTabs.length > 1) {
      const tabIds = grokTabs.map(t => t.id);
      const groupId = await chrome.tabs.group({ tabIds });
      await chrome.tabGroups.update(groupId, { title: 'Grok', color: 'green' });
      document.getElementById('groupList').innerHTML = `<p class="hint">✅ Grouped ${grokTabs.length} Grok tabs</p>`;
    } else {
      document.getElementById('groupList').innerHTML = '<p class="hint">Not enough Grok tabs to group</p>';
    }
  } catch (e) {
    document.getElementById('groupList').innerHTML = `<p class="hint">❌ Error: ${e.message}</p>`;
  }
}

async function groupXTabs() {
  document.getElementById('groupList').innerHTML = '<p class="hint">Grouping X/Twitter tabs...</p>';
  
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const xTabs = tabs.filter(t => t.url?.includes('x.com') || t.url?.includes('twitter.com'));
    
    if (xTabs.length > 1) {
      const tabIds = xTabs.map(t => t.id);
      const groupId = await chrome.tabs.group({ tabIds });
      await chrome.tabGroups.update(groupId, { title: 'X/Twitter', color: 'cyan' });
      document.getElementById('groupList').innerHTML = `<p class="hint">✅ Grouped ${xTabs.length} X tabs</p>`;
    } else {
      document.getElementById('groupList').innerHTML = '<p class="hint">Not enough X tabs to group</p>';
    }
  } catch (e) {
    document.getElementById('groupList').innerHTML = `<p class="hint">❌ Error: ${e.message}</p>`;
  }
}

// Platform detection helper for XKG Mobile
function detectXKGEndpoint() {
  // Try multiple common endpoints with correct XKG port (18050)
  const endpoints = [
    // Desktop local — primary XKG port
    { url: 'http://localhost:18050', platform: 'desktop', priority: 1 },
    // Android emulator (host machine) — XKG on desktop
    { url: 'http://10.0.2.2:18050', platform: 'android-emulator', priority: 2 },
    // iOS simulator  
    { url: 'http://localhost:18050', platform: 'ios-simulator', priority: 2 },
    // Physical Android device on same network
    { url: 'http://192.168.50.187:18050', platform: 'android-device', priority: 3 },
    // Web XKG alternative
    { url: 'http://localhost:8080', platform: 'web-alt', priority: 4 },
    // Legacy fallback
    { url: 'http://localhost:5000', platform: 'legacy', priority: 5 }
  ];
  
  return endpoints.sort((a, b) => a.priority - b.priority);
}

// Auto-detect available endpoint
async function autoDetectEndpoint() {
  const endpoints = detectXKGEndpoint();
  
  for (const ep of endpoints) {
    try {
      const res = await fetch(ep.url + '/api/health', { 
        method: 'HEAD',
        signal: AbortSignal.timeout(2000)
      });
      if (res.ok) {
        console.log('XKG found on', ep.platform, ep.url);
        return ep.url;
      }
    } catch (e) {
      // Try next
    }
  }
  
  return 'http://localhost:5000'; // Default
}

// Add auto-detect on load
console.log('TabMind: Auto-detecting XKG endpoint...');
autoDetectEndpoint().then(url => {
  document.getElementById('xkgEndpoint').value = url;
});

// Enhanced Grok URL detection - handles conversation IDs
function isGrokConversation(url) {
  // Match: x.com/i/grok?conversation=ID
  // Also match: x.com/grok, x.com/grokai, x.com/i/grok
  const patterns = [
    /x\.com\/i\/grok\?conversation=/i,
    /x\.com\/grok\?conversation=/i,
    /x\.com\/grok$/i,
    /x\.com\/grokai/i,
    /grok\.com/i,
    /x\.com\/i\/grok$/i
  ];
  return patterns.some(p => p.test(url));
}

// Extract conversation ID from URL
function getConversationId(url) {
  const match = url.match(/conversation[=\/](\d+)/i);
  return match ? match[1] : null;
}

// Enhanced content extraction for X/Grok conversations
async function extractGrokContent(tab) {
  try {
    // Get tab URL and extract conversation ID
    const url = tab.url || "";
    const convId = getConversationId(url);
    
    // Use Chrome scripting API to extract content
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const data = {
          title: document.title,
          url: window.location.href,
          timestamp: Date.now(),
          content: "",
          metadata: {}
        };
        
        // Find main content area
        const selectors = [
          [data-testid=cellInnerDiv],  // Timeline tweets
          article,                          // Article posts
          [role=article],                 // Generic articles
          main,                             // Main content
          .r-1hab5b2                        # Grok specific
        ];
        
        let content = "";
        for (const sel of selectors) {
          const els = document.querySelectorAll(sel);
          if (els.length > 0) {
            content = Array.from(els).map(e => e.textContent).join(" | ");
            if (content.length > 200) break;
          }
        }
        
        // Fallback to body
        if (!content || content.length < 100) {
          const body = document.body;
          const clone = body.cloneNode(true);
          
          // Remove unwanted elements
          const remove = ["script", "style", "nav", "footer", "header", ".promo", ".ad"];
          remove.forEach(s => {
            try { clone.querySelectorAll(s).forEach(e => e.remove()); } catch {}
          });
          
          content = clone.textContent;
        }
        
        data.content = content.slice(0, 50000);
        
        // Extract metadata
        data.metadata = {
          hasGrok: document.querySelector("[data-testid=grokPrompt]") !== null,
          tweetCount: document.querySelectorAll("[data-testid=tweet]").length,
          url: window.location.href
        };
        
        return data;
      }
    });
    
    return results[0]?.result || null;
  } catch (e) {
    console.error("Extract error:", e);
    return null;
  }
}

// Enhanced sync function
async function syncGrokConversations() {
  const endpoint = document.getElementById("xkgEndpoint").value || "http://localhost:5000";
  
  // Get all tabs
  const tabs = await chrome.tabs.query({});
  
  // Filter for Grok-related tabs
  const grokTabs = tabs.filter(t => t.url && isGrokConversation(t.url));
  
  console.log(`Found ${grokTabs.length} Grok tabs`);
  
  const results = [];
  
  for (const tab of grokTabs) {
    const data = await extractGrokContent(tab);
    if (data) {
      data.conversationId = getConversationId(tab.url);
      results.push(data);
    }
  }
  
  // Send to XKG
  try {
    const response = await fetch(endpoint + "/api/tab-import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tabs: results,
        source: "TabMind Chrome Extension",
        timestamp: Date.now()
      })
    });
    
    if (response.ok) {
      console.log(`✅ Synced ${results.length} conversations to XKG`);
    }
  } catch (e) {
    console.error("Sync error:", e);
  }
  
  return results.length;
}

console.log("✅ Enhanced Grok conversation extraction loaded");
console.log("   - isGrokConversation(url) - detects all Grok URLs");
console.log("   - getConversationId(url) - extracts conversation ID");
console.log("   - extractGrokContent(tab) - enhanced content extraction");
console.log("   - syncGrokConversations() - sync all Grok tabs");
