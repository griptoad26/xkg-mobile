const puppeteer = require('puppeteer-core');
const path = require('path');

const EXTENSION_PATH = path.join(__dirname);

async function test() {
  console.log('Starting Chrome with extension...');
  
  const browser = await puppeteer.launch({
    headless: false,
    args: [
      `--disable-extensions-except=${EXTENSION_PATH}`,
      `--load-extension=${EXTENSION_PATH}`,
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu'
    ],
    executablePath: '/usr/bin/google-chrome-stable',
    defaultViewport: null
  });

  console.log('Browser launched. Open chrome://extensions/ to see the extension.');
  console.log('Press Ctrl+C to exit.');
  
  // Keep alive
  process.stdin.resume();
}

test().catch(console.error);
