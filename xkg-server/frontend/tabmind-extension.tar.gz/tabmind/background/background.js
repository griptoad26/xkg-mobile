// XKG Tab Search - Background Service Worker

// XKG Server endpoint (auto-detected or hardcoded)
let XKG_ENDPOINT = 'http://localhost:18050';

// Detect XKG server
async function detectXKGEndpoint() {
  const endpoints = [
    'http://localhost:18050',
    'http://localhost:5000',
    'http://10.0.2.2:5000',
    'http://127.0.0.1:18050'
  ];
  
  for (const url of endpoints) {
    try {
      const resp = await fetch(url + '/api/health', { 
        method: 'GET',
        signal: AbortSignal.timeout(2000)
      });
      if (resp.ok) {
        XKG_ENDPOINT = url;
        console.log('XKG found at:', XKG_ENDPOINT);
        return url;
      }
    } catch {}
  }
  console.log('XKG not detected, using default:', XKG_ENDPOINT);
  return XKG_ENDPOINT;
}

// Send tab content to XKG server
async function sendToXKG(tabId, content, title, url, isGrok) {
  try {
    const body = {
      url: url,
      title: title,
      content: content,
      source: isGrok ? 'grok' : 'browser',
      timestamp: Date.now()
    };
    
    const resp = await fetch(XKG_ENDPOINT + '/api/tab-import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(5000)
    });
    
    if (resp.ok) {
      console.log('TabMind: Sent to XKG:', url.substring(0, 60));
      return true;
    }
  } catch (e) {
    console.log('TabMind: Failed to send to XKG:', e.message);
  }
  return false;
}

// Handle messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getTabContent') {
    getTabContent(message.tabId).then(result => {
      sendResponse(result);
    });
    return true;
  }
  
  if (message.action === 'syncGrok') {
    syncGrokTabs().then(sendResponse);
    return true;
  }
  
  if (message.action === 'setEndpoint') {
    XKG_ENDPOINT = message.endpoint;
    chrome.storage.local.set({ xkgEndpoint: XKG_ENDPOINT });
    sendResponse({ success: true });
    return true;
  }
  
  if (message.action === 'getEndpoint') {
    sendResponse({ endpoint: XKG_ENDPOINT });
    return true;
  }
});

// Index tab content when page loads
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    getTabContent(tabId).then(result => {
      if (result && result.text && result.text.length > 100) {
        // Auto-send to XKG if it's a Grok page
        const isGrok = tab.url.includes('x.com/grok') || tab.url.includes('grok.com') || tab.url.includes('/grok');
        if (isGrok || result.text.length > 500) {
          sendToXKG(tabId, result.text, result.title, result.url, isGrok);
        }
      }
    }).catch(() => {});
  }
});

async function getTabContent(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('brave://') || tab.url.startsWith('about:')) {
      return null;
    }
    
    if (tab.status !== 'complete' || tab.discarded) {
      return null;
    }
    
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: extractPageContent
    });
    
    const text = results[0]?.result || '';
    
    if (text && text.length > 10) {
      await chrome.storage.local.set({
        [`tab-content-${tabId}`]: {
          content: text,
          title: tab.title,
          url: tab.url,
          timestamp: Date.now()
        }
      });
      
      return { text, title: tab.title, url: tab.url };
    }
    
    return null;
  } catch (error) {
    console.error('Error getting tab content:', error);
    return null;
  }
}

function extractPageContent() {
  const excludeSelectors = [
    'script', 'style', 'noscript', 'iframe', 
    'nav', 'header', 'footer', 'aside',
    '.nav', '.menu', '.sidebar', '.ad', '.advertisement',
    '[role="navigation"]', '[role="banner"]', '[role="complementary"]'
  ];
  
  if (!document.body) return '';
  
  const clone = document.body.cloneNode(true);
  excludeSelectors.forEach(selector => {
    try {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    } catch (e) {}
  });
  
  let text = clone.body?.textContent || '';
  text = text.replace(/\s+/g, ' ').trim();
  return text.substring(0, 50000);
}

async function syncGrokTabs() {
  // Ensure XKG endpoint is set
  if (XKG_ENDPOINT === 'http://localhost:18050') {
    const stored = await chrome.storage.local.get('xkgEndpoint');
    if (stored.xkgEndpoint) XKG_ENDPOINT = stored.xkgEndpoint;
  }
  
  const tabs = await chrome.tabs.query({});
  const grokTabs = tabs.filter(tab => 
    tab.url && (tab.url.includes('x.com/grok') || tab.url.includes('grok.com') || tab.url.includes('/grok'))
  );
  
  const results = [];
  
  for (const tab of grokTabs) {
    const content = await getTabContent(tab.id);
    if (content) {
      const sent = await sendToXKG(tab.id, content.text, content.title, content.url, true);
      results.push({
        title: tab.title,
        url: tab.url,
        content: content.text,
        sent: sent,
        timestamp: Date.now()
      });
    }
  }
  
  return results;
}

// Auto-index active tab when switched
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  await getTabContent(activeInfo.tabId).catch(() => {});
});

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  detectXKGEndpoint();
});

// Run detection on startup
detectXKGEndpoint();
